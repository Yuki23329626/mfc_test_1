#include "vfw.h"

#define FULLSCREEN 0
#define WINDOW     1


#define PLAY  0
#define PAUSE 1
#define STOP  2
